# tutorial
**How to use**

# step 1 
Create bots https://discord.com/developers/applications
![image](https://github.com/vanishgg/VanishNuker/assets/169748142/dd40dac0-9509-46b4-bc70-7cb289ca1180)


# step 2
enable intents
![image](https://github.com/vanishgg/VanishNuker/assets/169748142/19f132ae-431b-4762-8fc8-8a1d16de3252)

# step 3 
invite the bots with admin perms.

# step 4
reset bots token and copy.
put tokens in tokens.txt in this format: (1 new line = new tkn
```
token
token
```
Run main.py or start.bat (run install.bat first to install everything needed)
run main.exe if you dont wanna install python 
