import os 
from colorama import Style
import discord
import asyncio
from datetime import datetime
import random
from gradientify import Colors

c = "\033[38;2;194;255;182m"
d = "\033[1;90m"
red = "\033[1;31m"
blue = "\033[1;34m"
w = "\033[1;37m"
r = Style.RESET_ALL
