<p align="center">
  <a href="https://github.com/vanishgg/vanish-recode">
    <img src="https://i.ibb.co/G9ctsGQ/nigga.png" alt="Logo" width="100" height="100">
  </a>
  <h3 align="center">Vanish Flooder</h3>
  <p align="center">
    Flood your friends dms.
    <br/>
    <a href="https://discord.gg/Mv4YQAK8F2">Our discord</a>
  </p>
</p>



<p align="center">
  <img src="https://img.shields.io/github/languages/top/vanishgg/vanish-flooder" alt="Top Language">
  <img src="https://img.shields.io/github/last-commit/vanishgg/vanish-flooder" alt="Last Commit">
  <img src="https://img.shields.io/github/issues-closed/vanishgg/vanish-flooder" alt="Issues Closed">
  <img src="https://img.shields.io/github/issues/vanishgg/vanish-flooder" alt="Issues">
  <img src="https://img.shields.io/github/stars/vanishgg/vanish-flooder" alt="Stars">
  <img src="https://img.shields.io/github/forks/vanishgg/vanish-flooder" alt="Forks">
</p>
<p><img src="https://i.postimg.cc/282DLwSX/image-63.webp" alt="Preview"></p>

<h2 id="about">About Vanish Flooder</h2>
<p>Vanish flooder is a tool to flood your friends dms.</p>

<h2>WARNING</h2>
<p><strong>⚠️ Only download Vanish from this GitHub repo, downloading from anywhere else might result in you getting malware</strong></p>

<h2>Disclaimer</h2>
<p><strong>THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY. USE AT YOUR OWN RISK. ANY ACTIONS YOU TAKE WITH THIS TOOL ARE YOUR OWN RESPONSIBILITY.</strong></p>

<h2>Requirements</h2>
<ul>
  <li>Bot tokens.</li>
  <li>A PC or laptop.</li>
  <li>a brain.</li>
</ul>


<h2>Links</h2>
<ul>
  <li>Website: <a href="https://vanishnet.netlify.app/">https://vanishnet.netlify.app/</a></li>
  <li>Discord: <a href="https://discord.gg/Mv4YQAK8F2">https://discord.gg/Mv4YQAK8F2</a></li>
  <li>YouTube: <a href="https://www.youtube.com/@kqfo">https://www.youtube.com/@kqfo</a></li>
</ul>



<p align="center">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&pause=1000&color=7B00FF&center=true&vCenter=true&width=380&lines=Vanish+flooder;Flood+your+friends+dms;made+by+virtual" alt="Typing SVG">
</p>
